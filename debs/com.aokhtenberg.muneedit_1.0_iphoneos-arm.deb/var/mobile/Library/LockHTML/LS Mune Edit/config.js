
var Twenty_Four_Hours = false; // Use 24-Hours System Instead of 12-Hours
var Round_Font = false; // Use Round Font
var Show_Battery = true; // Show The Battery Percent